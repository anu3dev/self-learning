import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Launch 
{

	public static void main(String[] args) 
	{
		try 
		{
			//Load& Registering the driver and 
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			System.out.println("Driver registered successfully!");
			
			// EstablishConnection
			
			String url ="jdbc:mysql://localhost:3306/teluskodb";
			String userName="root";
			String password="mypassword";
			Connection connect=DriverManager.getConnection(url, userName, password);
			
			System.out.println("Established connection!");
			
			//Create the Statement
			
			Statement stmnt=connect.createStatement();
			
			String query="UPDATE studentdetail set age=28 where id=3";
			//execute query
			int rowsAffected=stmnt.executeUpdate(query);
			
			
			
			if(rowsAffected ==1)
			{
				System.out.println("Update success");

			}
			else
			{
				System.out.println("Update failed");
			}
			
			//close resources
			stmnt.close();
			connect.close();
			
			
		} 
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	}


