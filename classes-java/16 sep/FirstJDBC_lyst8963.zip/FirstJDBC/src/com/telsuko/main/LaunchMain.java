package com.telsuko.main;
import java.sql.*;
public class LaunchMain 
{

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		
         //load and register the driver
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		System.out.println("Driver is registered successfully!");
		
		//Establish the connection
		
		String url="jdbc:mysql://localhost:3306/teluskodb";
		String userName="root";
		String password="mypassword";
		
		Connection connect=DriverManager.getConnection(url, userName, password);
		
		System.out.println("Connection is extablished");
		
		//Create statement object
		Statement stmt=connect.createStatement();
		
		//execute the query
		String query="select id, name, age, gender from studentdetail ";
		ResultSet result=stmt.executeQuery(query);
		
		System.out.println("Query is executed");
		
		System.out.println("ID\tNAME\tAGE\tGENDER");
		//process data 
	  while(result.next())
	  {
		  System.out.println(result.getInt(1)+ "\t" + result.getString(2) + "\t" +result.getInt(3)
		  
				  + "\t" + result.getString(4));
	  }
	  
	  //close resource
	  result.close();
	  stmt.close();
	  connect.close();
		
		
	}

}
