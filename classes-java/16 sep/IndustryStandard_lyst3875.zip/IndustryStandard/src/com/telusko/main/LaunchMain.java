package com.telusko.main;
import java.sql.*;

import com.telusko.util.Utility;
public class LaunchMain {

	public static void main(String[] args) 
	{
		//Resources
		Connection connect=null;
		Statement stmnt=null;
		ResultSet result=null;
		
		//get the connection
		try 
		{
			connect=Utility.getDbConnection();
			
			if(connect!=null)
				stmnt=connect.createStatement();
			
			if(stmnt!=null)
				result=stmnt.executeQuery("select id, name, age, gender from studentdetail");
			
			if(result!=null)
			{
				System.out.println("ID\tNAME\tAGE\tGENDER");
			
				//process data 
			  while(result.next())
			  {
				  System.out.println(result.getInt(1)+ "\t" + result.getString(2) + "\t" +result.getInt(3)
				  
						  + "\t" + result.getString(4));
			  }
		  
			}
				
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		
		finally 
		{
			try 
			{
				Utility.closeResource(result, stmnt, connect);
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}

	}

}
