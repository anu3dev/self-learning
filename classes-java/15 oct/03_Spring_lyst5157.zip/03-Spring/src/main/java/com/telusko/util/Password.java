package com.telusko.util;

public class Password 
{
    public Password(String algo)
    {
    	System.out.println("password object creating");
    }
}
