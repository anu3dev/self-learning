package com.telusko.main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
public class LaunchJDBC2 
{
	private static final Logger logger=Logger.getLogger(LaunchJDBC2.class);
	
	static {
		
		SimpleLayout layout =new SimpleLayout();
		ConsoleAppender consoleAppender=new ConsoleAppender(layout);
		logger.addAppender(consoleAppender);
		logger.setLevel(Level.DEBUG);
	}

	public static void main(String[] args) 
	{
		logger.debug("Start of main method");
		
		
		try 
		{
			//Load& Registering the driver and 
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//System.out.println("Driver registered successfully!");
			logger.info("Driver registered successfully!");
			
			// EstablishConnection
			
			String url ="jdbc:mysql://localhost:3306/teluskodb";
			String userName="root";
			String password="mypassword";
			Connection connect=DriverManager.getConnection(url, userName, password);
			
			//System.out.println("Established connection!");
			logger.info("Established connection!");
			//Create the Statement
			
			Statement stmnt=connect.createStatement();
			logger.debug("statement obj is created");
			
			//execute query
			
//			String query="INSERT INTO studentinfo (sid, sname, sage, saddr)"
//					+ " VALUES(2, 'Kohli', 18, 'Bangalore')";
			
			String query="DELETE from studentdetail where id=4";
			int rowsAffected=stmnt.executeUpdate(query);
			
			if(rowsAffected ==1)
			{
//				System.out.println("Data inserted successfully");
				System.out.println("Data Deleted successfully");

			}
			else
			{
				System.out.println("Failed to delete the data");
			}
			
			//close resources
			stmnt.close();
			connect.close();
			
			
		} 
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("ClassNotFoundException is generated");
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("SQLException is generated");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.fatal("Exception is generated not known which one");
		}

	}

}
