package com.telusko.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

import com.telusko.util.JdbcUtility;

public class LaunchMainP4 {
	
private static final Logger logger=Logger.getLogger(LaunchMainP4.class);
	
	static {
		
		SimpleLayout layout =new SimpleLayout();
		ConsoleAppender consoleAppender=new ConsoleAppender(layout);
		logger.addAppender(consoleAppender);
		logger.setLevel(Level.ERROR);
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		logger.debug("Start of main method");
		Connection connect=null;
		PreparedStatement pstmnt=null;
		ResultSet result=null;
		Scanner scan=null;
		
		try 
		{
			logger.info("Driver registered successfully!");
			connect=JdbcUtility.getDbConnection();
			
			logger.info("Established connection!");
		
			if(connect!=null)
			{
			String sql="Select sid, sname, sag, saddr from studentinfo where sid=?";
			
			pstmnt=connect.prepareStatement(sql);
			logger.debug("statement obj is created");
			
			}
			if(pstmnt!=null)
			{
			scan=new Scanner(System.in);
			System.out.println("Kindly enter the id ");
			Integer id=scan.nextInt();
			
			pstmnt.setInt(1, id);
			
			result=pstmnt.executeQuery();
			
			}
			if(result!=null)
			{
				if(result.next())
				{
					System.out.println("SID\tSNAME\tSAGE\tSADDR");
					System.out.println(result.getInt("sid") + "\t" + result.getString(2) + "\t" +
					
			           result.getInt(3) + "\t" + result.getString("saddr"));
				}
				else
				{
					System.out.println("Records not available for this id");
				}
				
			}
			
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
			logger.error("SQL Exception is generated");
			
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
			logger.fatal(" Exception is generated unknown");
			
		}
		
		finally
		{
			try 
			{
				JdbcUtility.closeResource(result, pstmnt, connect);
				scan.close();
			} 
			catch (SQLException e) 
			{
				
				e.printStackTrace();
				logger.error("SQL Exception is generated");
				
			}
		}


	}

}
