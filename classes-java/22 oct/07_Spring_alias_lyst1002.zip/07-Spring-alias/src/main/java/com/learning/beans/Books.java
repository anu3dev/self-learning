package com.learning.beans;

public class Books 
{
    public void readingBook()
    {
    	System.out.println("Reading books is very important..");
    }
}
