package com.learning.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.learning.entity.Branch;
import com.learning.entity.Students;

public class LaunchApp 
{

	public static void main(String[] args)
	{
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Transaction transaction = session.beginTransaction();
		
		Branch b=new Branch();
		b.setBid("T-1");
		b.setBranchName("Springers");
		b.setBlocation("Bengaluru");
		
		Students s1=new Students("Rohan", "Bengaluru", b);
		Students s2=new Students("Rohit", "pune", b);
		Students s3=new Students("Rahul", "Bengaluru", b);
		
		session.save(s1);
		session.save(s2);
		session.save(s3);
		
		transaction.commit();
		session.close();
		

	}

}
