package com.learning.main;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.learning.entity.Courses;
import com.learning.entity.Students2;

public class LaunchApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Transaction transaction = session.beginTransaction();
		
		Courses c1=new Courses("C-1", "Java", 2500);
		Courses c2=new Courses("C-2", "Springboot", 1500);
		Courses c3=new Courses("C-3", "SQL", 500);
		
		Set<Courses> set1=new HashSet<>();
		set1.add(c1);
		set1.add(c2);
		set1.add(c3);
		
		Set<Courses> set2=new HashSet<>();
		set2.add(c1);
		set2.add(c2);
		
		Set<Courses> set3=new HashSet<>();
		set3.add(c1);
		set3.add(c2);
		set3.add(c3);
		
		Students2 st1=new Students2("Rohan", "Bengaluru", set1);
		Students2 st2=new Students2("Rohit", "pune", set2);
		Students2 st3=new Students2("Rahul", "Mysuru", set3);
		
		session.save(st1);
		session.save(st2);
		session.save(st3);
		
		transaction.commit();
		session.close();
		
		
	}

}
