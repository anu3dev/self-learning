package com.learning.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.learning.entity.Students2;

public class Retrive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Students2 st1=session.get(Students2.class, 1);
		System.out.println(st1);
		System.out.println();
		System.out.println("*******************************");
		
		
		Students2 st2=session.get(Students2.class, 2);
		System.out.println(st2);
		System.out.println();
		System.out.println("*******************************");
		
		Students2 st3=session.get(Students2.class, 3);
		System.out.println(st3);
		System.out.println();
		System.out.println("*******************************");
		
		session.close();
	}

}
