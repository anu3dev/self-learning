package com.learning.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Courses 
{
	@Id
	private String cid;
	
	private String cname;
	
	private Integer ccost;
	
	public Courses()
	{
		System.out.println("Courses obj is created ");
	}
	public Courses(String cid, String cname, Integer ccost) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.ccost = ccost;
	}


	@Override
	public String toString() {
		return "Courses [cid=" + cid + ", cname=" + cname + ", ccost=" + ccost + "]";
	}

}
