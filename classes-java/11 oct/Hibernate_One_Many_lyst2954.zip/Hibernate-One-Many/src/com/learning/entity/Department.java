package com.learning.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department 
{
	@Id
	private String deptId;
	
	private String deptName;
	
//	private Employee2 emp;
	
	@OneToMany(cascade= CascadeType.ALL)
	private Set<Employee2> employee;

	public Department()
	{
		System.out.println("Dept obj created!!");
	}
	
	public String getDeptId() {
		return deptId;
	}



	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}



	public String getDeptName() {
		return deptName;
	}



	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}



	public Set<Employee2> getEmployee() {
		return employee;
	}



	public void setEmployee(Set<Employee2> employee) {
		this.employee = employee;
	}



	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName + ", employee=" + employee + "]";
	}
	
	
	
}
