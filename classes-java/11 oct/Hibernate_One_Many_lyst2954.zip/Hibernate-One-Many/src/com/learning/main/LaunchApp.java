package com.learning.main;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.learning.entity.Department;
import com.learning.entity.Employee2;

public class LaunchApp
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Transaction transaction = session.beginTransaction();
		
		Employee2 e1=new Employee2("Rohan", 34544.5f, "HR");
		Employee2 e2=new Employee2("Rohit", 44544.5f, "Ops");
		Employee2 e3=new Employee2("Ramesh", 54544.5f, "IT");
		Employee2 e4=new Employee2("Roshan", 64544.5f, "Dev");
		
		Set<Employee2> set= new HashSet<Employee2>();
		set.add(e1);
		set.add(e2);
		set.add(e3);
		set.add(e4);
		
		Department dep=new Department();
		dep.setDeptId("T245");
		dep.setDeptName("Ed-tech");
		dep.setEmployee(set);
		
		session.save(dep);
		
		transaction.commit();
		
		session.close();

	}

}
