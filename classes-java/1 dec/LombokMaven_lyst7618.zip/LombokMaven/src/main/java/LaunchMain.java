
public class LaunchMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee a=new Employee();
		a.setId(1);
		a.setName("Rohan");
		a.setAge(16);
		
		System.out.println(a);

	}

}
