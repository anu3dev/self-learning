package com.learning.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EmailUtil 
{
	@Autowired
	private PasswordGeneration password;
	
  public EmailUtil()
  {
	  System.out.println("Email util obj is created");
  }
  
  public boolean sendEmail()
  {
	  System.out.println("Email sent.....");
	  return true;
  }
  public boolean password()
  {
	  return password.generatePw();
  }
  
}
