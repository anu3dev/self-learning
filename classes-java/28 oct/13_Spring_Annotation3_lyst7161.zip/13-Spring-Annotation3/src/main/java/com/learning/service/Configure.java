package com.learning.service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.learning.util.PasswordGeneration;

@Configuration
public class Configure 
{
	public Configure()
	{
		System.out.println("Configuration");
	}
	
	@Bean
	public PasswordGeneration customizePassword()
	{
		PasswordGeneration password=new PasswordGeneration("SHA-1");
		return password;
	}

}
