package com.learning.util;


public class PasswordGeneration 
{
	public PasswordGeneration(String algo) 
	{
		System.out.println("Algo used for password is : "+ algo);
		System.out.println("Oassword obj created");
	}
	
	public boolean generatePw()
	{
		System.out.println("Password generated using SHA algo");
		return true;
	}
	
	
}
