package com.learning.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learning.dao.Dao;
import com.learning.util.EmailUtil;

@Service(value="service")
public class ProvidingService 
{
	
	private int id;
	private String name;
	private int age;
	
    public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setDao(Dao dao) {
		this.dao = dao;
	}

	public void setEmail(EmailUtil email) {
		this.email = email;
	}

	@Autowired 
	private Dao dao;
	
    @Autowired
    private EmailUtil email;
    
	public ProvidingService()
	{
		System.out.println("Service obj is created");
	}
	
	public boolean invockServices()
	{
		
		 email.sendEmail();
		 email.password();
		 return true;
		 
	
	}
	public boolean storeData()
	{
		dao.setAge(age);
		dao.setId(id);
		dao.setName(name);
		 dao.saveData();
		return true;
	}
}
