package com.learning.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.learning.service.ProvidingService;

public class LaunchApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		ProvidingService service =context.getBean("service", ProvidingService.class);
		boolean status=service.invockServices();
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter the id : ");
		int id=scan.nextInt();
		System.out.println("Please enter the name : ");
		String name=scan.next();
		System.out.println("Please enter the age : ");
		int age=scan.nextInt();
		
			service.setAge(age);
			service.setId(id);
			service.setName(name);
		
		if(status)
			System.out.println("App working fine");
		else
			System.out.println("some issue");
		
		boolean status2=service.storeData();
		if(status2)
			System.out.println("Data stored");
		else
			System.out.println("failed to store");
		
		System.out.println("************************************");
//		ProvidingService service2 =context.getBean("providingService", ProvidingService.class);
//		boolean status2=service2.invockServices();
//		if(status2)
//			System.out.println("Success in storing data");
//		else
//			System.out.println("Failed to store");
//	
	
	}

}
