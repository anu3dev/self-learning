package com.telusko.springwebex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebExApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebExApplication.class, args);
	}

}
