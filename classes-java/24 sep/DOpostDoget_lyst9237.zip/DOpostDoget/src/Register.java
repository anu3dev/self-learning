

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/reg")
public class Register extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

       System.out.println("Get request is processed!");
       String name=request.getParameter("username");
      String addr= request.getParameter("useraddr");
      
      System.out.println(name + " : "+ addr);
      
      response.sendRedirect("/DOpostDoget/success.html");
	}

}
