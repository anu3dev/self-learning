package com.telusko.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.telusko.util.JdbcUtility;

@WebServlet("/reg")
public class Register extends HttpServlet 
{

       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName=request.getParameter("username");
		String userAddr=request.getParameter("useraddr");
		String userAge=request.getParameter("userage");
		
		Connection connect=null;
		PreparedStatement pstmnt=null;
		String sql="INSERT INTO studentinfo (sid, sname, sage, saddr) VALUES(?,?,?,?)";
		PrintWriter writer=response.getWriter();
		writer.println("<html> <head> <title>Registeration</title></head>");
		try 
		{
			connect=JdbcUtility.getDbConnection();
			System.out.println("Connection is fine");
			pstmnt=connect.prepareStatement(sql);
			System.out.println("Query is fine");
			pstmnt.setInt(1, 2);
			pstmnt.setString(2, userName);
			pstmnt.setInt(3, Integer.parseInt(userAge));
			pstmnt.setString(4, userAddr);
			int rowsAffected=pstmnt.executeUpdate();
			System.out.println("Update");
			if(rowsAffected==1)
			{
				writer.println("<body><h1>Registration successfull! Check DB</h1></body>");
			}
			else
			{
				writer.println("<body><h1>Failed to register</h1></body>");
			}
			
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				JdbcUtility.closeResource( pstmnt, connect);
				writer.close();
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

}
