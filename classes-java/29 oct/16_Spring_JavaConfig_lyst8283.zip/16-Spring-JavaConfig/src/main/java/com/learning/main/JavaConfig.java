package com.learning.main;

import java.time.LocalDateTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages= {"com.learning"})
public class JavaConfig 
{
	public JavaConfig()
	{
		System.out.println("JavaConfig obj .......");
	}
	
	@Bean
	public LocalDateTime createDateObj()
	{
		System.out.println("Local date time obj createed as bean");
		return LocalDateTime.now();
	}

}
