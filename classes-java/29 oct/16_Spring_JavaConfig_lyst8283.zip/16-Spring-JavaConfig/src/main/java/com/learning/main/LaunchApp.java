package com.learning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class LaunchApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context= new AnnotationConfigApplicationContext(JavaConfig.class);
		WishGenerator wish=context.getBean(WishGenerator.class);
		System.out.println(wish);
		String wishes=wish.generateWishes();
		
		System.out.println(wishes);
	}

}
