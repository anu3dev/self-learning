package com.telusko.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
public class Employee 
{
	private Integer id;
	private String name;
	private String addr;
	private Integer salary;


public Employee()
   {
	   System.out.println("Employee obj");
   }


public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public void setId(Integer id) 
	{
		this.id = id;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public void setAddr(String addr) 
	{
		this.addr = addr;
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", addr=" + addr +", salary=" + salary + "]";
	}
	

}
