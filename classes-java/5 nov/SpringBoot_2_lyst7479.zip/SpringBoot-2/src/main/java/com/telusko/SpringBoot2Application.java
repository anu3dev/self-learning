package com.telusko;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.telusko.dao.EmployeeDao;
import com.telusko.model.Employee;

@SpringBootApplication
public class SpringBoot2Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(SpringBoot2Application.class, args);
		
		System.out.println("Beans created internally by Spring boot : "+
		Arrays.toString(context.getBeanDefinitionNames()));
		
		EmployeeDao empDao=context.getBean(EmployeeDao.class);
		List<Employee> list= empDao.getTheEmployee();
		Iterator itr=list.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		((ConfigurableApplicationContext) context).close();
		
		
		
	}

}
