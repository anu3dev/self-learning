package com.telusko.dao;

import java.util.List;

import com.telusko.model.Employee;

public interface IEmployeeDao 
{
   List<Employee> getTheEmployee();
}
