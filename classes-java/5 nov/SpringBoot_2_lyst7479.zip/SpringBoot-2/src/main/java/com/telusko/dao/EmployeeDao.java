package com.telusko.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telusko.model.Employee;

@Repository("empDao")
public class EmployeeDao implements IEmployeeDao
{
	
	private static final String SQL_QUERY ="select eid, ename, eaddress, salary from employee";
	@Autowired
	private DataSource dataSource;
	List<Employee> empList=null;
	
	
	public EmployeeDao()
	{
		System.out.println("Employee dao obj");
	}
	
	@Override
	public List<Employee> getTheEmployee() {
		System.out.println("DataSource : " + dataSource.getClass().getName());
		
		try 
		{
			Connection connect=dataSource.getConnection();
			PreparedStatement pstmt = connect.prepareStatement(SQL_QUERY);
			ResultSet rs=pstmt.executeQuery();
			
			 empList=new ArrayList<>();
			while(rs.next())
			{
				Employee emp=new Employee();
				emp.setId(rs.getInt(1));
				emp.setAddr(rs.getString(2));
				emp.setName(rs.getString(3));
				emp.setSalary(rs.getInt(4));
				empList.add(emp);
				
				
			}
			
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
		return empList;
	}
	
     
}
