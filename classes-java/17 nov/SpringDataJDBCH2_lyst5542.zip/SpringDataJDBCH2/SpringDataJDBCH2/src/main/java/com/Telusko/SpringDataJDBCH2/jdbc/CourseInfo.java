package com.Telusko.SpringDataJDBCH2.jdbc;

public class CourseInfo 
{
	private Integer id;
	private String cname;
	
	public CourseInfo() {
		super();
	
	}
	
	public CourseInfo(Integer id, String cname) {
		super();
		this.id = id;
		this.cname = cname;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getCname() {
		return cname;
	}


	public void setCname(String cname) {
		this.cname = cname;
	}


	@Override
	public String toString() {
		return "CourseInfo [id=" + id + ", cname=" + cname + "]";
	}
	
	

}
