package com.Telusko.SpringDataJDBCH2.jdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CourseCommanLineRunner implements CommandLineRunner
{

	@Autowired
	private SpringJdbcApp app;
	
	@Override
	public void run(String... args) throws Exception 
	{
	    app.insert(new CourseInfo(2, "Java"));
	    app.insert(new CourseInfo(3, "Spring Boot"));
	    app.insert(new CourseInfo(4, "Junit"));
	    
	    app.deleteById(2);
	    
	    System.out.println(app.findById(3));
	    System.out.println(app.findById(4));
	    
	    
		
	}

}
