package com.Telusko.SpringDataJDBCH2.jdbc;

import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class SpringJpaApp 
{
	@PersistenceContext
    private EntityManager entitymanager;
	
	
	public void insert(CourseInfo course)
	{
		System.out.println("Insertion through jpa");
		entitymanager.merge(course);
	}
	
	public CourseInfo findById(long id)
	{
		return entitymanager.find(CourseInfo.class,id);
	}
	
	
	public void deleteById(long id)
	{
		CourseInfo info=entitymanager.find(CourseInfo.class, id);
		entitymanager.remove(info);
	}
    
}
