package com.Telusko.SpringDataJDBCH2.jdbc;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataJpa extends JpaRepository<CourseInfo, Long>
{
       List<CourseInfo> findByName(String name);
}
