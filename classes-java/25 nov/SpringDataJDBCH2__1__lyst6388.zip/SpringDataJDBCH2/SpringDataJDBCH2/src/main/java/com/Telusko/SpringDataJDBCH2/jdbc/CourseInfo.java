package com.Telusko.SpringDataJDBCH2.jdbc;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity(name="Course")
public class CourseInfo 
{

	@Id
	private Integer id;
	
    @Column
	private String name;
	
	public CourseInfo() {
		super();
	
	}
	
	public CourseInfo(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setCname(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "CourseInfo [id=" + id + ", cname=" + name + "]";
	}
	
	

}
