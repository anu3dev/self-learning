package com.Telusko.SpringDataJDBCH2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJdbch2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJdbch2Application.class, args);
	}

}
