
public interface Courses 
{
    boolean selectCourse(Double amount);
}
