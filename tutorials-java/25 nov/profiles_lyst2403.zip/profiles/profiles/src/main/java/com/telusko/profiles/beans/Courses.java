package com.telusko.profiles.beans;

public interface Courses 
{
	boolean courseRegistered();

}
