package com.telusko.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.telusko.entity.Student;

public class LaunchApp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	
		
		
		//Activate the Hibernate
		
		Configuration config=new Configuration();
		
		//load the hibernate.config.xml file into the configuration Object
		config.configure("/hibernate.config.xml");
		
		//Build the session Factory object using configuration object
		//load and register driver, establish the connect and create the preparedstatement
		SessionFactory sessionFactory=config.buildSessionFactory();
		
		//To perform operation(Task) create on session object
		Session session=sessionFactory.openSession();
		
		//Begin the transaction w.r.t to particular session
		Transaction transaction=session.beginTransaction();
		
		Student std=new Student();
		std.setId(6);
		std.setName("Lakshmi");
		std.setAge(28);
		std.setAddress("Mumbai");
		
		//performing update operation and id which we are using must be present ==> update()
		//session.update(std);
		
		session.saveOrUpdate(std);
		
		//commit the operation
		transaction.commit();
		
		//close the session
		session.close();
		

	}

}
