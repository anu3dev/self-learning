package com.telusko.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.telusko.entity.Student;

public class LaunchApp1 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		Student std=new Student();
		std.setId(4);
		std.setName("Deb");
		std.setAge(27);
		std.setAddress("Bengaluru");
		
		
		//Activate the Hibernate
		
		Configuration config=new Configuration();
		
		//load the hibernate.config.xml file into the configuration Object
		config.configure("/hibernate.config.xml");
		
		//Build the session Factory object using configuration object
		//load and register driver, establish the connect and create the preparedstatement
		SessionFactory sessionFactory=config.buildSessionFactory();
		
		//To perform operation(Task) create on session object
		Session session=sessionFactory.openSession();
		
		//Begin the transaction w.r.t to particular session
		Transaction transaction=session.beginTransaction();
		
		
		//performing insert operation
		session.save(std);
		
		//commit the operation
		transaction.commit();
		
		//close the session
		session.close();
		
		

	}

}
