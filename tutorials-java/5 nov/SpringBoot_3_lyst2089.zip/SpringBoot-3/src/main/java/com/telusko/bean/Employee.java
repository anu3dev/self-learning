package com.telusko.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp")
public class Employee 
{
	@Value("${info.employee.name}")
	private String name;
	
	@Value("${info.employee.age}")
	private int age;
	
	@Value("${info.employee.city}")
	private String address;
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", address=" + address + "]";
	}
	
	

}
