package com.Telusko.LoggingSpringBoot1;

public interface Course 
{
	boolean selectCourse(Double amount);
}
