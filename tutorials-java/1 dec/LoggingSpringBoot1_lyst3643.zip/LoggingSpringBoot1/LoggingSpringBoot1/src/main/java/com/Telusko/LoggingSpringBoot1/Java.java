package com.Telusko.LoggingSpringBoot1;


import org.slf4j.*;
import org.springframework.stereotype.Component;

@Component("java")
public class Java implements Course
{
	private  Logger logger=LoggerFactory.getLogger(Java.class);
//	static
//	{
//		System.out.println("Java class loaded");
//	}
	public Java()
	{
		logger.debug("Java obj is created");
		System.out.println("Java Obj is created");
	}

	public boolean selectCourse(Double amount) 
	{
		logger.info("Java course is selected");
		System.out.println("Enrolled in Java and amount paid is : "+ amount);
		return true;
	}

}
