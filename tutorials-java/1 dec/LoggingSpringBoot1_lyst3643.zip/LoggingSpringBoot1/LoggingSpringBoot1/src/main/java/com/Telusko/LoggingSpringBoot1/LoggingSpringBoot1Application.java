package com.Telusko.LoggingSpringBoot1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class LoggingSpringBoot1Application {

	public static void main(String[] args) 
	{
		ApplicationContext context = SpringApplication.run(LoggingSpringBoot1Application.class, args);
		
		CourseSelecting cs=(CourseSelecting) context.getBean("courseSelecting");
		cs.chooseCourse(114.4);
	}

}
