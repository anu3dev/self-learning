package com.Telusko.LoggingSpringBoot1;



import org.slf4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;



@Component
public class CourseSelecting 
{
	
	@Autowired
	@Qualifier("java")
	private Course course ; /// new Java();
	  Logger logger=LoggerFactory.getLogger(CourseSelecting.class);
     
//	static
//	{
//		System.out.println("CourseSelecting class loaded");
//	}
	
//	public CourseSelecting(Course course)
//	{
//		System.out.println("Constructor injection");
//		this.course=course;
//	}
	
public Course getCourse() 
{
	return course;
}
	public CourseSelecting()
	{
		logger.debug("CourseSelecting is Instantiated");
		System.out.println("Course Selecting target obj is created");
	}

   //setter
	public void setCourse(Course course) 
	{
		System.out.println("Setter injection");
		this.course = course;
	}

	public boolean chooseCourse(Double amount)
	{
		logger.info("Course would be decided here ");
//		course.selectCourse(amount);
//		return true;
		//logger.info("Amount for this course is "+ amount + " course selected is "+ course);
		return course.selectCourse(amount);
		
	}
}
