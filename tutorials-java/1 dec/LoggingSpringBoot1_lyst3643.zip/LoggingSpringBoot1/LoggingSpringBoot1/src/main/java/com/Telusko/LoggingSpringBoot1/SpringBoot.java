package com.Telusko.LoggingSpringBoot1;


import org.slf4j.*;
import org.springframework.stereotype.Component;

@Component("sp")
public class SpringBoot implements Course
{
	private Logger logger=LoggerFactory.getLogger(SpringBoot.class);
//	static
//	{
//		System.out.println("SB class loaded");
//	}

	public SpringBoot()
	{
		logger.debug("Spring obj is created");
		System.out.println("Spring obj is created");
	}
	public boolean selectCourse(Double amount) 
	{
		logger.info("Spring boot course is selected");
		System.out.println("Enrolled in SpringBoot and amount paid is : "+ amount);
		return true;
	}

}

