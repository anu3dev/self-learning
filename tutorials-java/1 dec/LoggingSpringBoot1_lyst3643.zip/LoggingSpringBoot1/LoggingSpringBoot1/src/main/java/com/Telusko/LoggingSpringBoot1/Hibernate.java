package com.Telusko.LoggingSpringBoot1;


import org.slf4j.*;
import org.springframework.stereotype.Component;

@Component("hibernate")
public class Hibernate implements Course
{
	private Logger logger=LoggerFactory.getLogger(Hibernate.class);
//	{
//		System.out.println("Hibernate class loaded");
//	}
	public Hibernate()
	{
		logger.debug("Hibernate obj is created");
		System.out.println("Hibernate obj is created");
	}

	public boolean selectCourse(Double amount) 
	{
		logger.info("Hibernate course is selected");
		System.out.println("Enrolled in Hibernate and amount paid is : "+ amount);
		return true;
	}

}
