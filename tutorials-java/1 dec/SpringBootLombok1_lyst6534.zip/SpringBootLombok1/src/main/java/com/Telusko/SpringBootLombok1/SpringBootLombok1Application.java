package com.Telusko.SpringBootLombok1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLombok1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLombok1Application.class, args);
	}

}
