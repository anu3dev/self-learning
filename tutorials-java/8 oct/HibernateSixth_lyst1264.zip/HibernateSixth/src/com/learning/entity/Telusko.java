package com.learning.entity;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity(name="TELUSKO")
public class Telusko 
{
	@Id
	@Column(name="ID")
	private Integer id;
	
	@Column(name="NAME")
	private String name;
	
	@Lob
	@Column(name="IMG")
	private byte[] img;
	
	@Lob
	@Column(name="DOC")
	private char[] characters;
	
	public Telusko()
	{
		System.out.println("Telusko obj is created!!");
	}

	@Override
	public String toString() {
		return "Telusko [id=" + id + ", name=" + name + ", img=" + Arrays.toString(img) + ", characters="
				+ Arrays.toString(characters) + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte[] getImg() {
		return img;
	}

	public void setImg(byte[] img) {
		this.img = img;
	}

	public char[] getCharacters() {
		return characters;
	}

	public void setCharacters(char[] characters) {
		this.characters = characters;
	}
}
