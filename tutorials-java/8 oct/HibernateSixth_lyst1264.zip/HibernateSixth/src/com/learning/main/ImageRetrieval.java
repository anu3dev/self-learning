package com.learning.main;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.learning.entity.Telusko;

public class ImageRetrieval 
{

	public static void main(String[] args) throws IOException 
	{
		SessionFactory sessionFactory = new Configuration().configure("/hibernate.config.xml").
				addAnnotatedClass(Telusko.class).buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Telusko t=session.get(Telusko.class, 4);
		System.out.println("Telusko id : "+ t.getId());
		System.out.println("Telusko Name : "+ t.getName());
		
		byte image[]=t.getImg();
		FileOutputStream fos=new FileOutputStream("D:\\Hyder\\telusko.jpeg");
		fos.write(image);
		
		fos.flush();
		
		char cr[]=t.getCharacters();
		FileWriter fw=new FileWriter("D:\\Hyder\\telusko.txt");
		fw.write(cr);
		fw.flush();
		
		session.close();
		fos.close();
		fw.close();

	}

}
