package com.learning.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.learning.entity.Telusko;


public class LaunchImage {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = new Configuration().configure("/hibernate.config.xml").
				addAnnotatedClass(Telusko.class).buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction trans = session.beginTransaction();
		
		Telusko t=new Telusko();
		
		t.setId(4);
		t.setName("Hyder");
		
		FileInputStream fis = new FileInputStream("D:\\Hyder\\Course.jpeg");
		byte byteArr[]=new byte[fis.available()];
		fis.read(byteArr);
		t.setImg(byteArr);
		
		String textFile="this is texts from text files";
		char ar[]=textFile.toCharArray();
		t.setCharacters(ar);
		
		session.save(t);
		trans.commit();
		
		session.close();
		
		
		
		
		

	}

}
