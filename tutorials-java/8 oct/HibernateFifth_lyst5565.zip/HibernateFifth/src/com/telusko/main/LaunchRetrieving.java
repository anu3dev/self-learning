package com.telusko.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.telusko.entity.Springers;

public class LaunchRetrieving {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = new Configuration().configure("/hibernate.config.xml").
				addAnnotatedClass(Springers.class).buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Integer id=4;
		Springers sp=session.get(Springers.class, id);
		
		if(sp!=null)
		System.out.println(sp);
		else
			System.out.println("No record with id : "+ id);
		
		
		session.close();
	}

}

