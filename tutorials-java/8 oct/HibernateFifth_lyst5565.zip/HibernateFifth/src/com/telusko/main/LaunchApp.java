package com.telusko.main;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.telusko.entity.Springers;

public class LaunchApp 
{

	public static void main(String[] args) 
	{
		SessionFactory sessionFactory = new Configuration().configure("/hibernate.config.xml").
				addAnnotatedClass(Springers.class).buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
//		
//		emp.setDate(LocalDate.now());
//		emp.setTime(LocalTime.now());
//		emp.setDateTime(LocalDateTime.now());

		
		Springers sp=new Springers();
		sp.setId(4);
		sp.setName("Mahesh");
		sp.setDt1(new Date());
		sp.setDt2(new Date());
		sp.setDt3(new Date());
		
		session.save(sp);
		
		transaction.commit();
		session.close();

	}

}
