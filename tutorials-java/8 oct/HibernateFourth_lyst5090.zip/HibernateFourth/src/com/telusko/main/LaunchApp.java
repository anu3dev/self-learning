package com.telusko.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.telusko.entity.Student;

public class LaunchApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		Integer id=5;
		Student st=session.get(Student.class, id);
		
		if(st!=null)
		{
			Transaction transaction = session.beginTransaction();
			session.delete(st);
			transaction.commit();
		}
		else
		{
			System.out.println("Record of the mentioned id is not available : "+ id);
		}
		
		
		session.close();
	}

}
