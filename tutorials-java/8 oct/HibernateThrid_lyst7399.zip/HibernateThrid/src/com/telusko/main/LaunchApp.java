package com.telusko.main;

import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.telusko.entity.Student;

public class LaunchApp 
{

	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
//		Configuration configure = new Configuration();
//		
//		configure.configure("/hibernate.config.xml");
//		
//		SessionFactory sessionFactory = configure.buildSessionFactory();
		
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		Student std=session.get(Student.class, 4);
		
		System.out.println("Student id     : "+ std.getId());
		System.out.println("Student name   : "+ std.getName());
		System.out.println("Student age    : "+ std.getAge());
		System.out.println("Student address: "+ std.getAddress());
		
//		System.in.read();
//		
//        Student std1=session.get(Student.class, 4);
//		
//		System.out.println("Student id     : "+ std1.getId());
//		System.out.println("Student name   : "+ std1.getName());
//		System.out.println("Student age    : "+ std1.getAge());
//		System.out.println("Student address: "+ std1.getAddress());
		session.close();
		
		
	}

}
