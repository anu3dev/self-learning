package com.telusko.main;

import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.telusko.entity.Student;

public class LaunchMainLoad 
{

	public static void main(String[] args) throws IOException 
	{
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Student std1=session.load(Student.class, 5);
		
		
		System.out.println("Student id : "+std1.getId());
		
		
		System.in.read();
		
		System.out.println("Student name : "+std1.getName());
		System.out.println("Student age : "+std1.getAge());
		System.out.println("Student Address : "+std1.getAddress());
		
		session.close();
	}

}
