package com.learning.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.learning.beans.Voter;

public class LaunchApp {

	public static void main(String[] args) 
	{
		System.out.println("Container started.......");
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		Voter voter=context.getBean(Voter.class);
		System.out.println(voter);
		voter.checkingEligibility();
		
		context.close();
		

		
		System.out.println("Container Stopped/destroyed.......");

	}

}
