package com.learning.beans;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component(value="voter")
@PropertySource(value="com/learning/commons/application.properties")
public class Voter 
{
	@Value("${voter.info.name}")
	private String name;

	@Value("${voter.info.age}")
	private int age;
	
	private Date dov;
	
	static
	{
		System.out.println("Voter class loaded.........static block");
	}
	
	public Voter()
	{
		System.out.println("Voter obj is created........Constructor");
	}
	@PostConstruct
	public void myInit()
	{
		System.out.println("init.. called");
		dov=new Date();
	}
	
	//business logic
	public String checkingEligibility()
	{
		System.out.println("Business logic method: Actual activity or method");
		if(age>18)
			return "Mr/Miss/Mrs : "+ name + " you're eleigible for voting as ypur age is : "+ age;
		else
			return "Mr/Miss/Mrs : "+ name + " you're not eleigible for voting as ypur age is : "+ age;
	}
	@PreDestroy
	public void myDestroy()
	{
		System.out.println("Destroy....");
		name=null;
		age=0;
		dov=null;
	}
	
	@Override
	public String toString() {
		return "Voter [name=" + name + ", age=" + age + ", dov=" + dov + "]";
	}
}
