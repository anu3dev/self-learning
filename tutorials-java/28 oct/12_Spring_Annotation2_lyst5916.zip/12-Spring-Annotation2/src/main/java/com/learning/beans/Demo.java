package com.learning.beans;

public class Demo 
{

}
