package com.learning.beans;

import org.springframework.stereotype.Component;

@Component
public class FirstFlight implements Courier
{
	   public FirstFlight()
	   {
		   System.out.println("FightFlight obj created");
	   }
	public boolean deliver(String oid) 
	{
		System.out.println("Delivered using FirstFlight service and order id : "+ oid);
		return true;
	}

}
