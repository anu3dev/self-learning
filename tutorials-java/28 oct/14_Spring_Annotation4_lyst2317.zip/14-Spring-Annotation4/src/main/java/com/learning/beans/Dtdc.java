package com.learning.beans;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName="prototype")
public class Dtdc implements Courier
{
	   public Dtdc()
	   {
		   System.out.println("Dtdc obj created");
	   }
	public boolean deliver(String oid) 
	{
		System.out.println("Delivered using Dtdc service and order id : "+ oid);
		return true;
	}

}
