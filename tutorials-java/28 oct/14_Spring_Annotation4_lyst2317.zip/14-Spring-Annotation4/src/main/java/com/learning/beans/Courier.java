package com.learning.beans;

public interface Courier 
{
	boolean deliver(String oid);

}
