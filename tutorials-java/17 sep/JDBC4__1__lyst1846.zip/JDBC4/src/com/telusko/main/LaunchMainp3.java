package com.telusko.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.telusko.util.JdbcUtility;

public class LaunchMainp3 
{

	public static void main(String[] args) 
	{
		//Resources
				Connection connect=null;
				PreparedStatement pstmnt=null;
				ResultSet result=null;
				Scanner scan=null;
				
				try 
				{
					connect=JdbcUtility.getDbConnection();
					String sql="DELETE from studentinfo where sid=?";
					pstmnt=connect.prepareStatement(sql);
					
					scan=new Scanner(System.in);
					System.out.println("Please enter the id which needs to be deleted");
					Integer id=scan.nextInt();
					
					pstmnt.setInt(1, id);
					int rows=pstmnt.executeUpdate();
					if(rows==1)
						System.out.println("Success");
					else
						System.out.println("Failed!");
				} 
				catch (SQLException e) 
				{
					
					e.printStackTrace();
				}
				
				finally
				{
					try 
					{
						JdbcUtility.closeResource(result, pstmnt, connect);
						scan.close();
					} 
					catch (SQLException e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

	}

}
