package com.telusko.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.telusko.util.JdbcUtility;

public class LaunchMainP2 
{

	public static void main(String[] args) 
	{
		//Resources
		Connection connect=null;
		PreparedStatement pstmnt=null;
		ResultSet result=null;
		Scanner scan=null;
		
		try 
		{
			connect=JdbcUtility.getDbConnection();
		
			System.out.println("Connection also fine!");
			if(connect!=null)
			{
			 String sql="UPDATE studentinfo set sname=? where sid=?";
			 pstmnt=connect.prepareStatement(sql);
			 
			 scan=new Scanner(System.in);
			 System.out.println("Please enter info that needs to be updated");
			 System.out.println("Kindly enter your id: ");
			 Integer id=scan.nextInt();
			 System.out.println("Please enter your correct name");
			 String name=scan.next();
			 
			 pstmnt.setString(1, name);
			 pstmnt.setInt(2, id);
			 boolean status=pstmnt.execute();
			
			System.out.println(status);
			if(status ==true)
			{
				result=pstmnt.getResultSet();
			}
			else
			{
				int rows=pstmnt.getUpdateCount();
				if(rows>0)
				{
					System.out.println("Success");
				}
				else
				{
					System.out.println("Failed!");
				}
			}
			
			}
			
		
		} 
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				JdbcUtility.closeResource(result, pstmnt, connect);
				scan.close();
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
