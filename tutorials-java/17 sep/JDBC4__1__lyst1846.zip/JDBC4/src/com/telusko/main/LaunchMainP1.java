package com.telusko.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.telusko.util.JdbcUtility;

public class LaunchMainP1 {

	public static void main(String[] args) 
	{
		//Resources
				Connection connect=null;
				PreparedStatement pstmnt=null;
				ResultSet result=null;
				Scanner scan=null;
				
				
				try 
				{
					connect=JdbcUtility.getDbConnection();
					System.out.println("Connection also fine!");
					if(connect!=null)
						{
						 String sql="INSERT INTO studentinfo (sid, sname, sage, saddr) VALUES(?,?,?,?)";
						 pstmnt=connect.prepareStatement(sql);
						}
					if(pstmnt!=null)
					{
						System.out.println("Please enter the following details to be stored in DB");
						scan=new Scanner(System.in);
						System.out.println("Enter your id");
						Integer id=scan.nextInt();
						
						System.out.println("Enter your name");
						String name=scan.next();
						
						System.out.println("Enter your age");
						Integer age=scan.nextInt();
						
						System.out.println("Enter your Addrs");
						String addr=scan.next();
						
						pstmnt.setInt(1, id);
						pstmnt.setString(2, name);
						pstmnt.setInt(3, age);
						pstmnt.setString(4, addr);
						
						int rowsAffected=pstmnt.executeUpdate();
						if(rowsAffected==1)
						{
							System.out.println("Operation success");
						}
						else
						{
							System.out.println("Operation failed!");
						}
						
						
					}
					
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				finally 
				{
					try 
					{
						JdbcUtility.closeResource(result, pstmnt, connect);
						scan.close();
					} 
					catch (SQLException e) 
					{
						
						e.printStackTrace();
					}
				}
				

	}

}
