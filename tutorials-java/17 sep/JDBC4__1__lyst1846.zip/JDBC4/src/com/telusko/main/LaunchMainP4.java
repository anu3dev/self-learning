package com.telusko.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.telusko.util.JdbcUtility;

public class LaunchMainP4 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		Connection connect=null;
		PreparedStatement pstmnt=null;
		ResultSet result=null;
		Scanner scan=null;
		
		try 
		{
			connect=JdbcUtility.getDbConnection();
			if(connect!=null)
			{
			String sql="Select sid, sname, sage, saddr from studentinfo where sid=?";
			pstmnt=connect.prepareStatement(sql);
			}
			if(pstmnt!=null)
			{
			scan=new Scanner(System.in);
			System.out.println("Kindly enter the id ");
			Integer id=scan.nextInt();
			
			pstmnt.setInt(1, id);
			
			result=pstmnt.executeQuery();
			}
			if(result!=null)
			{
				if(result.next())
				{
					System.out.println("SID\tSNAME\tSAGE\tSADDR");
					System.out.println(result.getInt("sid") + "\t" + result.getString(2) + "\t" +
					
			           result.getInt(3) + "\t" + result.getString("saddr"));
				}
				else
				{
					System.out.println("Records not available for this id");
				}
				
			}
			
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		
		finally
		{
			try 
			{
				JdbcUtility.closeResource(result, pstmnt, connect);
				scan.close();
			} 
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}
		}


	}

}
