insert into student (name, age) values ('Alice', 20);
insert into student (name, age) values ('Bob', 22);
insert into student (name, age) values ('Carol', 21);
insert into student (name, age) values ('Dave', 23);
insert into student (name, age) values ('Eve', 25);
insert into student (name, age) values ('Frank', 24);
insert into student (name, age) values ('Grace', 27);
insert into student (name, age) values ('Heidi', 26);
