

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/reg")
public class Register1 extends HttpServlet 
{
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("username");
		String addr=request.getParameter("useraddr");
		String courses[]=request.getParameterValues("course");
		
		System.out.println("Able to fetch the data");
		
		PrintWriter pw=response.getWriter();
		pw.println("<html> <head> <title>Registeration</title></head>");
		pw.println("<body>");
		pw.println("<table border='1'>");
		pw.println("<tr><td>USERNAME</td><td>" + name + "</td></tr>");
		pw.println("<tr><td>USERAddress</td><td>" + addr + "</td></tr>");
		for(String c:courses)
		{
			pw.println("<tr>");
			pw.println("<td>CourseSelected</td><td>"+ c+ "</td>");
			pw.println("</tr>");
		}
		pw.println("</table>");
		pw.println("</body>");
		pw.println("</html>");
		pw.close();
	}

}
