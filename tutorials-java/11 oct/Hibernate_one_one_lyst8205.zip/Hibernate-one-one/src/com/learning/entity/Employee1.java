package com.learning.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Employee1
{
 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer empid;
	
	
	private String ename;
	
	private Float esalary;
	
	private String eaddress;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Account account;
	



	public String getEname() {
		return ename;
	}




	public void setEname(String ename) {
		this.ename = ename;
	}




	public Float getEsalary() {
		return esalary;
	}




	public void setEsalary(Float esalary) {
		this.esalary = esalary;
	}




	public String getEaddress() {
		return eaddress;
	}




	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}




	public Account getAccount() {
		return account;
	}




	public void setAccount(Account account) {
		this.account = account;
	}




	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", esalary=" + esalary + ", eaddress=" + eaddress
				+ ", account=" + account + "]";
	}
	
	
	
	
}
