package com.learning.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.learning.entity.Employee1;

public class RetreiveApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Employee1 emp=session.get(Employee1.class, 1);
		System.out.println(emp);
		
		session.close();

	}

}
