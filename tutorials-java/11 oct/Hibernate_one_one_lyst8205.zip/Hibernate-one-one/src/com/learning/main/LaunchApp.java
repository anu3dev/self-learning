package com.learning.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.learning.entity.Account;
import com.learning.entity.Employee1;

public class LaunchApp 
{

	public static void main(String[] args) 
	{
		SessionFactory sessionFactory=new Configuration().configure("/hibernate.config.xml").buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Transaction transaction = session.beginTransaction();
		
		Account acc=new Account();

		acc.setAccNo("T123");
		acc.setAccName("Rohan");
		acc.setAccType("saving");
		
	    Employee1 emp=new Employee1();
		emp.setAccount(acc);
		emp.setEaddress("Bengaluru");
		emp.setEname("Rohan");
		emp.setEsalary(45000.5f);
		
		session.save(emp);
		
		transaction.commit();
		
		session.close();
	}

}
