package com.telusko.beans;

public interface Course 
{
	boolean selectCourse(Double amount);
}
