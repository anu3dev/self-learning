package com.telusko.beans;

public interface Pay 
{
	boolean makePayment(Double amount);
}
